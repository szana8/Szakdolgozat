<?php

    /**
     * Link: 
     * File: ${name}.php
     * Namespace: ${namespace}
     * 
     * Description of ${name}
     * 
     * 
     *  Version     Date            Author               Changelog   
     *   1.0.0      ${date}     ${user}              Created
     * 
     */

<#if namespace?? && namespace?length &gt; 0>
namespace ${namespace};
</#if>

class ${name} {
    //put your code here
}

?>